package TP2.app;

import java.time.LocalDate;

public abstract class Epass {
   private long codigo;
   private double saldo;
   private double precoViagem;
   private LocalDate dataCarrega;
   private LocalDate dataValida;
   private static long ultCodigo;

   static {
       if (Long.valueOf(ultCodigo)==null)
           ultCodigo=0;
   }
   public Epass()
   {
       this.codigo=ultCodigo+1;
       this.dataCarrega=LocalDate.now();
       ultCodigo++;




   }
    public Epass(double saldo, double precoViagem) {
        this.codigo=ultCodigo+1;
        ultCodigo++;
        this.saldo = saldo;
        this.precoViagem = precoViagem;
        this.dataCarrega=LocalDate.now();


    }
    public Epass( double precoViagem) {
        this.codigo=ultCodigo+1;
        ultCodigo++;
        this.precoViagem = precoViagem;
        this.dataCarrega=LocalDate.now();


    }



    public long getCodigo() {
        return codigo;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getPrecoViagem() {
        return precoViagem;
    }

    public LocalDate getDataCarrega() {
        return dataCarrega;
    }

    public LocalDate getDataValida() {
        return dataValida;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setPrecoViagem(double precoViagem) {
        this.precoViagem = precoViagem;
    }

    public void setDataCarrega(LocalDate dataCarrega) {
        this.dataCarrega = dataCarrega;
    }

    public void setDataValida(LocalDate dataValida) {
        this.dataValida = dataValida;
    }


}
