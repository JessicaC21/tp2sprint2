package TP2.app;

public interface TituloTransport {
    public void carregar(double carrega);
    public void pagarViagem(double Viagem);
    public boolean checkValidade();
    public boolean passarSaldo (double PasseStandard );










}
