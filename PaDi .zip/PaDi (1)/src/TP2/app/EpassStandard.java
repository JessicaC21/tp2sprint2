package TP2.app;

public abstract  class EpassStandard extends Epass{
    private Titular titular;
    private int pontos;
    private int num_Viagens;






}
