package TP2.app;

public class EpassFestival {
    private double saldoCartao;
    private String nomeEvento;

    public EpassFestival(double saldoCartao, String nomeEvento) {
        this.saldoCartao = saldoCartao;
        this.nomeEvento = nomeEvento;
    }
    public EpassFestival( String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }
    public EpassFestival(EpassFestival outro) {
        this.saldoCartao = outro.saldoCartao;
        this.nomeEvento = outro.nomeEvento;
    }

    public double getSaldoCartao() {
        return saldoCartao;
    }

    public void setSaldoCartao(double saldoCartao) {
        this.saldoCartao = saldoCartao;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }
}
