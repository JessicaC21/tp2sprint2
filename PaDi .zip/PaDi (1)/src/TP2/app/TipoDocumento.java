package TP2.app;

public enum TipoDocumento {
    BI,
    PASSAPORTE,
    TRE,
    CNI,
}
