package TP2.app;

import java.util.ArrayList;

public class EpassStudent {
    private String escola;
    private int AnoFrequenta;
    private int Viagemfree;
    private ArrayList <Zona> zonas;


    public EpassStudent(String escola, int anoFrequenta) {
        zonas= new ArrayList<>();
        this.escola = escola;
        AnoFrequenta = anoFrequenta;
    }
    public EpassStudent(EpassStudent outro) {
        this.escola = outro.escola;
        AnoFrequenta = outro.AnoFrequenta;

    }
   public boolean addZona(String nome){
        boolean status=false;
        for(Zona z:zonas){
            if(z.getNome().equalsIgnoreCase(nome)){
                status=true;
                break;
            }
        }
        if(!status){
            Zona novo = new Zona(nome);
            zonas.add(novo);
        }

        return status;




   }




}
