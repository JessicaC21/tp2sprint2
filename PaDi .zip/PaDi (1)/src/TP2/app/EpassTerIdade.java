package TP2.app;

import java.time.LocalDate;

public class EpassTerIdade {
    private LocalDate horaIni;

    public EpassTerIdade() {
        this.horaIni = LocalDate.now();
    }

    public LocalDate getHoraini() {
        return horaIni;
    }

    public void setHoraini(LocalDate hora) {
        this.horaIni = hora;
    }
}