package TP2.app;

public class Zona {
    private int ID;
    private String nome;

    public Zona(String nome) {
        this.nome = nome;
    }
    public Zona(Zona novo) {
        this.nome = novo.nome;
    }


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome() {
        return nome;
    }

}
