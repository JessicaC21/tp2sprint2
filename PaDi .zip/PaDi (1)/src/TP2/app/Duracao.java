package TP2.app;

public enum Duracao {
    Sete(7,1500),
    Tres(3,700),
    Um(1,500),







}
