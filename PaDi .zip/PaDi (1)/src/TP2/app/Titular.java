package TP2.app;

import java.io.Serializable;
import java.time.LocalDate;

public class Titular implements Serializable {
private final DocumentoID docID;
private String nome;
private LocalDate DataNasc;
private String morada;
private String email;
private int Telefone;

   public Titular(String codigoDoc ,TipoDocumento tipoDoc ,String nome, LocalDate dataNasc, String email) {
      this.docID=new DocumentoID(codigoDoc,tipoDoc);
      this.nome = nome;
      this.DataNasc = dataNasc;
      this.email = email;
   }
   public Titular(String codigoDoc ,TipoDocumento tipoDoc ,String nome, LocalDate dataNasc, int telefone) {
      this.docID=new DocumentoID(codigoDoc,tipoDoc);
      this.nome = nome;
      this.DataNasc = dataNasc;
      this.Telefone =telefone;
   }
}
