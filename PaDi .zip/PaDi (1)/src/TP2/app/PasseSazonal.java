package TP2.app;

public abstract class PasseSazonal {
 private Chave chaveValida;

    public Chave getChaveValida() {
        return chaveValida;
    }

    public void setChaveValida(Chave chaveValida) {
        this.chaveValida = chaveValida;
    }
}
