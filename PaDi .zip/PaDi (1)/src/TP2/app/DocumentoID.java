package TP2.app;

import java.io.Serializable;

public class DocumentoID implements Serializable {
    private final String codigoID;
    private final TipoDocumento tipo;

    public DocumentoID (String codigoID, TipoDocumento tipo) {
        this.codigoID = codigoID;
        this.tipo = tipo;
    }
    public DocumentoID(DocumentoID doc) {
        this.codigoID = doc.codigoID;
        this.tipo = doc.tipo;
    }

    public String getCodigoID() {
        return codigoID;
    }

    public TipoDocumento getTipo() {
        return tipo;
    }
}
